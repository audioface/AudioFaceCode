package file;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import QueryPOJOs.Example;
import QueryPOJOs.Item;
import face.Face;

/**
 * Servlet implementation class ParseQueryJSON
 */
@WebServlet("/ParseQueryJSON")
public class ParseQueryJSON extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//create the list of playlists
		ArrayList<String> happyPlaylists = new ArrayList<String>(Arrays.asList("Mood Booster","Happy Hits!","Happy Beats","Feelin' Good"));
		ArrayList<String> contemptPlaylists = new ArrayList<String>(Arrays.asList("Fresh Finds","Walk Like A Badass","Swagger"));
		ArrayList<String> disgustPlaylists = new ArrayList<String>(Arrays.asList("Justin Bieber: Best Of"));
		ArrayList<String> fearPlaylists = new ArrayList<String>(Arrays.asList("Noir","Dark & Stormy","Femme Fatale","Lost In Space"));
		ArrayList<String> angerPlaylists = new ArrayList<String>(Arrays.asList("Rage Beats","Rage Quit","Rage Rap","Rage Beats"));
		ArrayList<String> neutralPlaylists = new ArrayList<String>(Arrays.asList("A Perfect Day","Lush + Atmospheric","Country Coffeehouse","Safe For Work"));
		ArrayList<String> sadPlaylists = new ArrayList<String>(Arrays.asList("All The Feels","Down In The Dumps","Feeling Down","Drifting Apart"));
		ArrayList<String> surprisePlaylists = new ArrayList<String>(Arrays.asList("Stay Wild","Ready For The Day","Organic Experimental","Morning K-Pop!"));
		//make the API Calls
		HttpSession session = request.getSession();
		Face face = (Face) session.getAttribute("face");
		//get token from somewhere
		String token = (String) session.getAttribute("accessToken");
		String emotion = getEmotion(face);
		ArrayList<String> playlistIDs = new ArrayList<String>();
		ArrayList<String> correctPlaylists = null;
		if(emotion == "Happy") {
			correctPlaylists = happyPlaylists;
		}
		else if(emotion == "Sad") {
			correctPlaylists = sadPlaylists;
		}
		else if(emotion == "Angry") {
			correctPlaylists = angerPlaylists;
		}
		else if(emotion == "Disgusted") {
			correctPlaylists = disgustPlaylists;
		}
		else if(emotion == "Contempt") {
			correctPlaylists = contemptPlaylists;
		}
		else if(emotion == "Fear") {
			correctPlaylists = fearPlaylists;
		}
		else if(emotion == "Neutral") {
			correctPlaylists = neutralPlaylists;
		}
		else if(emotion == "Surprised") {
			correctPlaylists = surprisePlaylists;
		}
		for(int i=0; i < correctPlaylists.size(); i++) {
			String playlistID = parseQueryJSON(correctPlaylists.get(i), token);
			playlistIDs.add(playlistID);
		}
		//send the playlist ID's to get tracks servlet
		session.setAttribute("playlistIDs", playlistIDs);
		session.setAttribute("emotion", emotion);
		System.out.println("Searched by Emotion");
		String isGuest = (String) session.getAttribute("isGuest");
		if(isGuest.equals("true")) {
			RequestDispatcher rd = request.getRequestDispatcher("/GuestPlaylist");
			rd.forward(request, response);
		}
		else{
			RequestDispatcher rd = request.getRequestDispatcher("/GetTracksFromPlaylistJSON");
			rd.forward(request, response);
		}
		//RequestDispatcher rd = request.getRequestDispatcher("/GetTracksFromPlaylistJSON");
		//rd.forward(request, response);
	}
	
	public String getEmotion(Face face) {
		double max = 0;
		int emotion = 0;
		double happy = face.getFaceAttributes().getEmotion().getHappiness();
		double sad = face.getFaceAttributes().getEmotion().getSadness();
		double angry = face.getFaceAttributes().getEmotion().getAnger();
		double disgusted = face.getFaceAttributes().getEmotion().getDisgust();
		double contempt = face.getFaceAttributes().getEmotion().getContempt();
		double fear = face.getFaceAttributes().getEmotion().getFear();
		double neutral = face.getFaceAttributes().getEmotion().getNeutral();
		double surprise = face.getFaceAttributes().getEmotion().getSurprise();
		
		ArrayList<String> emotionName = new ArrayList<String>();
		emotionName.add("Happy");
		emotionName.add("Sad");
		emotionName.add("Angry");
		emotionName.add("Disgusted");
		emotionName.add("Contempt");
		emotionName.add("Fear");
		emotionName.add("Neutral");
		emotionName.add("Surprised");
		ArrayList<Double> emotionValue = new ArrayList<Double>();
		emotionValue.add(happy);
		emotionValue.add(sad);
		emotionValue.add(angry);
		emotionValue.add(disgusted);
		emotionValue.add(contempt);
		emotionValue.add(fear);
		emotionValue.add(neutral);
		emotionValue.add(surprise);
		for(int i=0; i<8; i++) {
			if(emotionValue.get(i) > max) {
				max = emotionValue.get(i);
				emotion = i;
			}
		}
		System.out.println(emotionName.get(emotion));
		return emotionName.get(emotion);
	}
	
	public String parseQueryJSON(String query, String token) {
		String myQuery = query.replaceAll(" ", "%20");
		String apiURL = "https://api.spotify.com/v1/search?q="+myQuery+"&type=playlist&limit=1&offset=0";
		String basicAuth = token;
		URL weatherURL;
		String playlistID = "";
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("GET");
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example queryPOJO = gson.fromJson(list.toString(), Example.class);
	        playlistID = queryPOJO.getPlaylists().getItems().get(0).getId();
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
		return playlistID;
	}

}
