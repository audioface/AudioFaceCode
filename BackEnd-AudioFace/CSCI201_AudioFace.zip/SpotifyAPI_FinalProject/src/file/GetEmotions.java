package file;

import java.io.File;
import java.net.URI;

import javax.servlet.http.HttpSession;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.FileEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class GetEmotions {
	
	// Replace <Subscription Key> with your valid subscription key.
    private static final String subscriptionKey = "d25925263c114ab29628570fd6663cea";

    // NOTE: You must use the same region in your REST call as you used to
    // obtain your subscription keys. For example, if you obtained your
    // subscription keys from westus, replace "westcentralus" in the URL
    // below with "westus".
    //
    // Free trial subscription keys are generated in the "westus" region. If you
    // use a free trial subscription key, you shouldn't need to change this region.
    private static final String uriBase =
        "https://centralus.api.cognitive.microsoft.com/face/v1.0/detect";

//    private static final String imageWithFaces =
//        "{\"url\":\"https://upload.wikimedia.org/wikipedia/commons/c/c3/RH_Louise_Lillian_Gish.jpg\"}";

    private static final String faceAttributes =
        "age,gender,headPose,smile,facialHair,glasses,emotion,hair,makeup,occlusion,accessories,blur,exposure,noise";
    
    public static void main(String[] args) {
		//get file path for saved photo
//		HttpSession session = request.getSession();
		//change later to be dynamic
//    			String filePath = (String) session.getAttribute("filePath");
		String filePath = "/Users/vivianzzhu/Desktop/AudioFace/photo0.jpg";
		System.out.println("My file is in "+ filePath);
		String imageWithFaces = filePath;
		
		HttpClient httpclient = HttpClientBuilder.create().build();

        try
        {
            URIBuilder builder = new URIBuilder(uriBase);

            // Request parameters. All of them are optional.
            builder.setParameter("returnFaceId", "true");
            builder.setParameter("returnFaceLandmarks", "false");
            builder.setParameter("returnFaceAttributes", faceAttributes);

            // Prepare the URI for the REST API call.
            URI uri = builder.build();
            HttpPost httprequest = new HttpPost(uri);

            // Request headers.
            httprequest.setHeader("Content-Type", "application/json");
            httprequest.setHeader("Ocp-Apim-Subscription-Key", subscriptionKey);

            // Request body
            File file = new File(imageWithFaces);
            FileEntity reqEntity = new FileEntity(file, ContentType.APPLICATION_OCTET_STREAM);
            httprequest.setEntity(reqEntity);

            // Execute the REST API call and get the response entity.
            HttpResponse httpresponse = httpclient.execute(httprequest);
            HttpEntity entity = httpresponse.getEntity();

            if (entity != null)
            {
                // Format and display the JSON response.
                System.out.println("REST Response:\n");

                String jsonString = EntityUtils.toString(entity).trim();
                if (jsonString.charAt(0) == '[') {
                    JSONArray jsonArray = new JSONArray(jsonString);
                    System.out.println(jsonArray.toString(2));
                }
                else if (jsonString.charAt(0) == '{') {
                    JSONObject jsonObject = new JSONObject(jsonString);
                    System.out.println(jsonObject.toString(2));
                } else {
                    System.out.println(jsonString);
                }
            }
        }
        catch (Exception e)
        {
            // Display error message.
            System.out.println(e.getMessage());
        }
    }
    
    
}
