package file;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import PlaylistPOJOs.Example;

/**
 * Servlet implementation class GetTracksFromPlaylistJSON
 */
@WebServlet("/GetTracksFromPlaylistJSON")
public class GetTracksFromPlaylistJSON extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		ArrayList<String> playlistIDs = (ArrayList<String>) session.getAttribute("playlistIDs");
		//get token
		String token = (String) session.getAttribute("accessToken");
		Vector<String> trackMasterList = new Vector<String>();
		for(int i=0; i<playlistIDs.size(); i++) {
			Vector<String> tracks = getTracks(playlistIDs.get(i), token);
			trackMasterList.addAll(tracks);
		}
		session.setAttribute("trackMasterList", trackMasterList);
		//send the playlist ID's to get tracks servlet
		System.out.println("Gathered all the songs");
		//redirect to guest flow if null
		String isGuest = (String) session.getAttribute("isGuest");
		if(isGuest.equals("true")) {
			RequestDispatcher rd = request.getRequestDispatcher("/CreatePlaylist");
			rd.forward(request, response);
		}
		else {
			RequestDispatcher rd = request.getRequestDispatcher("/GetUserInformation");
			rd.forward(request, response);
		}
	}
	
	public Vector<String> getTracks(String playlistID, String token) {
		Vector<String> trackIdVect = new Vector<String>();
		String apiURL = "https://api.spotify.com/v1/playlists/"+playlistID+"/tracks?market=US&limit=20&offset=0";
		String basicAuth = token;
		URL weatherURL;
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("GET");
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example queryPOJO = gson.fromJson(list.toString(), PlaylistPOJOs.Example.class);
	        List<PlaylistPOJOs.Item> myTrackList = queryPOJO.getItems();
	        for(int i=0; i<myTrackList.size(); i++) {
	        	//System.out.println(myTrackList.get(i).getTrack().getName() + " by " + myTrackList.get(i).getTrack().getArtists().get(0).getName());
	        	trackIdVect.add(myTrackList.get(i).getTrack().getUri());
	        }
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
		//return a vector of ID strings for all the songs
		return trackIdVect;
	}

}
