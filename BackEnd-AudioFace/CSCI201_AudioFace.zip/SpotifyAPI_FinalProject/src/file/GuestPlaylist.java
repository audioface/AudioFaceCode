package file;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GuestPlaylist
 */
@WebServlet("/GuestPlaylist")
public class GuestPlaylist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		System.out.println("Inside Guest Playlist!");
		String emotion = (String) session.getAttribute("emotion");
		Vector<String> happyPlaylists = new Vector<String>(Arrays.asList("Happy by Pharrell Williams","Happy Now by Zedd","Happy Kids by John De Sohn"));
		Vector<String> contemptPlaylists = new Vector<String>(Arrays.asList("Howlin' For You by The Black Keys","Can't Stop by Red Hot Chili Peppers","Glory by The Score"));
		Vector<String> disgustPlaylists = new Vector<String>(Arrays.asList("Love Yourself by Justin Bieber", "Sorry by Justin Bieber", "What Do You Mean? by Justin Bieber"));
		Vector<String> fearPlaylists = new Vector<String>(Arrays.asList("Bohemia by Mt. Wolf","Stars by Sam Airey","Sleeper by whenyoung"));
		Vector<String> angerPlaylists = new Vector<String>(Arrays.asList("Burn by Say My Name","RAMPAGE by GRAVEDGR","YuNg BrAtZ by XXXTENTACION"));
		Vector<String> neutralPlaylists = new Vector<String>(Arrays.asList("You by Kyson","Stay Awake by Dean Lewis","Brighter Shade of Blue by Jordan DePaul"));
		Vector<String> sadPlaylists = new Vector<String>(Arrays.asList("Don't by Bryson Tiller","Die For You by The Weeknd","Let Her Go by Passenger"));
		Vector<String> surprisePlaylists = new Vector<String>(Arrays.asList("Beige by Yoke Lore","Lazuli Bunting by Andrew Bird","Mikrokosmos by BTS"));
		Vector<String> correctPlaylists = new Vector<String>();
		if(emotion == "Happy") {
			correctPlaylists = happyPlaylists;
		}
		else if(emotion == "Sad") {
			correctPlaylists = sadPlaylists;
		}
		else if(emotion == "Angry") {
			correctPlaylists = angerPlaylists;
		}
		else if(emotion == "Disgusted") {
			correctPlaylists = disgustPlaylists;
		}
		else if(emotion == "Contempt") {
			correctPlaylists = contemptPlaylists;
		}
		else if(emotion == "Fear") {
			correctPlaylists = fearPlaylists;
		}
		else if(emotion == "Neutral") {
			correctPlaylists = neutralPlaylists;
		}
		else if(emotion == "Surprised") {
			correctPlaylists = surprisePlaylists;
		}
		session.setAttribute("correctPlatlist", correctPlaylists);
		RequestDispatcher rd = request.getRequestDispatcher("/SendDataServlet");
		rd.forward(request, response);
	}

}
