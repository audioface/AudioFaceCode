package face;

import java.util.HashMap;
import java.util.Map;

public class FacialHair {

private Double sideburns;
private Double beard;
private Double moustache;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public Double getSideburns() {
return sideburns;
}

public void setSideburns(Double sideburns) {
this.sideburns = sideburns;
}

public Double getBeard() {
return beard;
}

public void setBeard(Double beard) {
this.beard = beard;
}

public Double getMoustache() {
return moustache;
}

public void setMoustache(Double moustache) {
this.moustache = moustache;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}