package face;

import java.util.HashMap;
import java.util.Map;

public class HairColor {

private String color;
private Double confidence;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public String getColor() {
return color;
}

public void setColor(String color) {
this.color = color;
}

public Double getConfidence() {
return confidence;
}

public void setConfidence(Double confidence) {
this.confidence = confidence;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}